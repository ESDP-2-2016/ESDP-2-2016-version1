Phonelib.default_country = "KG"
Phonelib.parse_special = true
Phonelib.strict_check = true
Phonelib.extension_separator = ';'
Phonelib.extension_separate_symbols = '#;'