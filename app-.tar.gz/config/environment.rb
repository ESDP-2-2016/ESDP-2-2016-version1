# Load the Rails application.
require_relative 'application'

# Initialize the Rails application.
Rails.application.initialize!


ENV['RECAPTCHA_SITE_KEY']  = '6LffCAkUAAAAALEh6FTmIVPHIbU8SgYYmI7xQTPD'
ENV['RECAPTCHA_SECRET_KEY'] = '6LffCAkUAAAAAEEl1Km1iCE86C9cXgp_bWvSa1Ru'