class ApplicationMailer < ActionMailer::Base
  default from: 'socialhubs2016@gmail.com'
  layout 'mailer'
end
