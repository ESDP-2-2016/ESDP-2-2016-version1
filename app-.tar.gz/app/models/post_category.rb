class PostCategory < ApplicationRecord
  has_many :posts
end
