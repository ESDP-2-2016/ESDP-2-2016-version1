class MetaTag < ApplicationRecord
end
