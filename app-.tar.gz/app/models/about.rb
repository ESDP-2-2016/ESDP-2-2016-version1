class About < ApplicationRecord
end
