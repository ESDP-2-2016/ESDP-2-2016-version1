module AidsHelper
end
