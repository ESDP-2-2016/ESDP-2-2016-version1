#= require active_admin/base
var CKEDITOR_BASEPATH = '/assets/ckeditor/';